import { config } from 'dotenv';
config();

import '@/ai/flows/recommend-adjustments.ts';
