'use client';

import React from 'react';
import FormularioCarga from '@/components/services/FormularioCarga';

export default function Page() {
  return <FormularioCarga />;
}
