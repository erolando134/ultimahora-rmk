export const firebaseConfig = {
  apiKey: "AIzaSyBuA8vYdEeoAhtTkYz1mPfu8l_e8eIpeFY",
  authDomain: "ultimahora-8cdd7.firebaseapp.com",
  projectId: "ultimahora-8cdd7",
  storageBucket: "ultimahora-8cdd7.appspot.com",
  messagingSenderId: "64761922059",
  appId: "1:64761922059:web:97a111af73246f946e3d0e",
  measurementId: "G-E6QJLPFG3N"
};
