'use client';

export default function PublicarEmpleo() {
  return (
    <main className="p-6 text-white min-h-screen bg-gray-900 flex flex-col items-center justify-center">
      <h1 className="text-3xl font-bold mb-4">Aquí irá la lógica para Publicar Empleo para Choferes</h1>
      <p className="text-lg">Próximamente podrás publicar vacantes de empleo.</p>
    </main>
  );
}
